python predict.py;
python predict1.py
