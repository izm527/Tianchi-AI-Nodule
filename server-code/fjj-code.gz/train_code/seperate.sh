python seperate_nodule_v2.py
python seperate_nodule_v2-1.py
